Definition: A string representing the taxonomic identification as it appeared in the original record.

Notes: This term is meant to allow the capture of an unaltered original identification/determination, including identification qualifiers, hybrid formulas, uncertainties, etc.
Examples:
- Peromyscus sp.
- Ministrymon sp. nov. 1
- Anser anser × Branta canadensis
- Pachyporidae?
- Potentilla × pantotricha Soják
- Aconitum pilipes × A. variegatum
- Lepomis auritus x cyanellus

Will always be in latin and could have extra text attached that isn't, to specify two different, instances of the same specie.