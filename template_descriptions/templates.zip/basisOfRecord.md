Definition: The specific nature of the data record.
Notes:	Recommended best practice is to use a controlled vocabulary such as the set of local names of the identifiers for classes in Darwin Core.
Valid values for basisOfRecord (Darwin Core):
- PreservedSpecimen: A specimen that has been collected and preserved (e.g., pinned, pressed, collected in ethanol, dried, frozen). Most museum specimens fall here.
- LivingSpecimen: A specimen that is alive and maintained (e.g., in a botanical garden, zoo, seed bank, or culture collection).
- HumanObservation: A record based on a human observing the organism in its environment, where the data depends on seeing the organism alive or in situ.Use HumanObservation even when specimens were also collected for identification — what matters is HOW the data point was obtained, not whether vouchers exist.

Important rules:
- The basisOfRecord depends on HOW the measurement was obtained, not just whether specimens were collected.
- Behavior, nesting, microhabitat, and ecological observations → HumanObservation, even if specimens were preserved.
- Morphological measurements (body length, wing size, weight, anatomy) that require examining a preserved specimen → PreservedSpecimen.
- A single paper can produce records with different basisOfRecord values depending on what each measurement is about.

Many papers do not explicitly state the basisOfRecord, but it can often be inferred from the methods section, figure captions, or table captions.
Often studies generalize for more than one species in the paper and to save time they might mention the family or the order or mention "all", so you might have to infer it based on the content of the paper.
