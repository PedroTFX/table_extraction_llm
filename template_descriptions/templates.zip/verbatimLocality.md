Describe the `verbatimLocality` tag here.

Definition: The locality string as given in the source (free-text description of place).

Examples:
- "Near Riverbank, 5 km NW of Town"
- "Mount Example, Australia"

Guidance: Preserve original wording and punctuation; do not attempt to geocode here. If locality needs normalization, record separate normalized fields.