The nature of the measurement, fact, characteristic, or assertion.Recommended best practice is to use a controlled vocabulary.Whereas this term allows for any string literal value.
Examples:	
- body size
- wing length
- weight
- respiration rate
- 3D morphometry
- tail length
- temperature
- trap line length
- survey area
- trap type